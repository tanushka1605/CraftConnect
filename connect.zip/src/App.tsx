import { useState } from 'react';
import { WelcomeScreen } from './components/WelcomeScreen';
import { LanguageSelection } from './components/LanguageSelection';
import { LoginScreen } from './components/LoginScreen';
import { ViewModeSelection } from './components/ViewModeSelection';
import { VoiceRegistration } from './components/VoiceRegistration';
import { MainApp } from './components/MainApp';
import { BuyerView } from './components/BuyerView';

export type Language = 'hindi' | 'bengali' | 'tamil' | 'telugu' | 'marathi' | 'english';
export type Craft = 'pottery' | 'weaving' | 'painting' | 'woodwork' | 'metalwork';

export interface User {
  name: string;
  craft: Craft;
  language: Language;
  mobile: string;
}

function App() {
  const [currentScreen, setCurrentScreen] = useState<'welcome' | 'login' | 'language' | 'viewMode' | 'registration' | 'main'>('welcome');
  const [selectedLanguage, setSelectedLanguage] = useState<Language>('english');
  const [mobileNumber, setMobileNumber] = useState('');
  const [user, setUser] = useState<User | null>(null);
  const [viewMode, setViewMode] = useState<'buyer' | 'seller'>('buyer');

  const handleStartVoice = () => {
    setCurrentScreen('login');
  };

  const handleLoginComplete = (mobile: string) => {
    setMobileNumber(mobile);
    setCurrentScreen('language');
  };

  const handleLanguageSelect = (language: Language) => {
    setSelectedLanguage(language);
    setCurrentScreen('viewMode');
  };

  const handleViewModeSelect = (mode: 'buyer' | 'seller') => {
    setViewMode(mode);
    if (mode === 'seller') {
      setCurrentScreen('registration');
    } else {
      // For buyers, skip registration
      setUser({
        name: 'User',
        craft: 'pottery',
        language: selectedLanguage,
        mobile: mobileNumber
      });
      setCurrentScreen('main');
    }
  };

  const handleRegistrationComplete = (craft: Craft, name: string) => {
    setUser({
      name,
      craft,
      language: selectedLanguage,
      mobile: mobileNumber
    });
    setCurrentScreen('main');
  };

  const handleModeChange = (mode: 'buyer' | 'seller') => {
    setViewMode(mode);
  };

  return (
    <div className="min-h-screen bg-[#FBF8F3] flex items-center justify-center p-4">
      <div className="w-full max-w-[360px] h-[800px] bg-[#FBF8F3] shadow-2xl rounded-3xl overflow-hidden relative">
        {currentScreen === 'welcome' && (
          <WelcomeScreen onLogin={handleStartVoice} />
        )}
        {currentScreen === 'login' && (
          <LoginScreen onLoginComplete={handleLoginComplete} />
        )}
        {currentScreen === 'language' && (
          <LanguageSelection onSelectLanguage={handleLanguageSelect} />
        )}
        {currentScreen === 'viewMode' && (
          <ViewModeSelection 
            language={selectedLanguage}
            onSelectMode={handleViewModeSelect}
          />
        )}
        {currentScreen === 'registration' && (
          <VoiceRegistration 
            language={selectedLanguage} 
            onComplete={handleRegistrationComplete}
          />
        )}
        {currentScreen === 'main' && user && (
          <>
            {viewMode === 'seller' ? (
              <MainApp user={user} viewMode={viewMode} onModeChange={handleModeChange} />
            ) : (
              <BuyerView viewMode={viewMode} onModeChange={handleModeChange} />
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default App;