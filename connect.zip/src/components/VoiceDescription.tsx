import { useState } from 'react';
import { motion } from 'motion/react';
import { Language } from '../App';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface VoiceDescriptionProps {
  language: Language;
  onComplete: (description: string) => void;
  imageUrl: string;
}

const translations = {
  hindi: {
    title: 'अपने उत्पाद के बारे में बताएं',
    subtitle: 'Describe your product',
    listening: 'सुन रहे हैं...',
    speak: 'बोलें',
    example: 'Example: "Handmade clay pot, traditional design"',
  },
  bengali: {
    title: 'আপনার পণ্য বর্ণনা করুন',
    subtitle: 'Describe your product',
    listening: 'শুনছি...',
    speak: 'বলুন',
    example: 'Example: "Handmade clay pot, traditional design"',
  },
  tamil: {
    title: 'உங்கள் தயாரிப்பை விவரிக்கவும்',
    subtitle: 'Describe your product',
    listening: 'கேட்கிறேன்...',
    speak: 'பேசு',
    example: 'Example: "Handmade clay pot, traditional design"',
  },
  telugu: {
    title: 'మీ ఉత్పత్తిని వివరించండి',
    subtitle: 'Describe your product',
    listening: 'వింటున్నాను...',
    speak: 'మాట్లాడండి',
    example: 'Example: "Handmade clay pot, traditional design"',
  },
  marathi: {
    title: 'तुमच्या उत्पादनाचे वर्णन करा',
    subtitle: 'Describe your product',
    listening: 'ऐकत आहे...',
    speak: 'बोला',
    example: 'Example: "Handmade clay pot, traditional design"',
  },
  english: {
    title: 'Describe your product',
    subtitle: 'Tell us about it',
    listening: 'Listening...',
    speak: 'Speak',
    example: 'Example: "Handmade clay pot, traditional design"',
  },
};

export function VoiceDescription({ language, onComplete, imageUrl }: VoiceDescriptionProps) {
  const [isListening, setIsListening] = useState(false);
  const [transcription, setTranscription] = useState('');

  const t = translations[language] || translations.english;

  const handleMicClick = () => {
    setIsListening(true);
    
    // Simulate voice recognition
    setTimeout(() => {
      const mockDescription = 'Handmade clay pot with traditional design, perfect for home decor';
      setTranscription(mockDescription);
      setIsListening(false);
      
      // Auto-proceed after showing transcription
      setTimeout(() => {
        onComplete(mockDescription);
      }, 1500);
    }, 2500);
  };

  return (
    <div className="h-full flex flex-col p-6 bg-gradient-to-b from-[#FBF8F3] to-[#E8F5E9] pb-28">
      {/* Title */}
      <div className="text-center mb-6">
        <h2 className="text-2xl text-[#2E7D32] mb-1">{t.title}</h2>
        <p className="text-lg text-[#558B2F]">{t.subtitle}</p>
      </div>

      {/* Product Image Preview */}
      <div className="w-full h-48 rounded-2xl overflow-hidden shadow-lg mb-6">
        <ImageWithFallback
          src={imageUrl}
          alt="Product"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Microphone */}
      <div className="flex-1 flex flex-col items-center justify-center">
        <motion.button
          onClick={handleMicClick}
          disabled={isListening || transcription !== ''}
          className="w-32 h-32 rounded-full bg-[#FF6F00] flex items-center justify-center shadow-2xl active:scale-95 transition-transform disabled:opacity-50"
          animate={isListening ? {
            scale: [1, 1.1, 1],
            boxShadow: [
              '0 0 0 0 rgba(255, 111, 0, 0.4)',
              '0 0 0 20px rgba(255, 111, 0, 0)',
              '0 0 0 0 rgba(255, 111, 0, 0)',
            ],
          } : {}}
          transition={{ duration: 1.5, repeat: isListening ? Infinity : 0 }}
        >
          <span className="text-6xl">🎤</span>
        </motion.button>

        <p className="text-xl text-[#2E7D32] mt-6 text-center">
          {isListening ? t.listening : t.speak}
        </p>

        {/* Waveform animation */}
        {isListening && (
          <div className="flex gap-2 mt-6">
            {[...Array(7)].map((_, i) => (
              <motion.div
                key={i}
                className="w-2 bg-[#FF6F00] rounded-full"
                animate={{
                  height: [20, 50, 20],
                }}
                transition={{
                  duration: 0.5,
                  repeat: Infinity,
                  delay: i * 0.08,
                }}
              />
            ))}
          </div>
        )}

        {/* Transcription */}
        {transcription && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6 bg-white p-4 rounded-xl shadow-md w-full"
          >
            <p className="text-[#2E7D32] text-center">"{transcription}"</p>
          </motion.div>
        )}
      </div>

      {/* Example Hint */}
      {!isListening && !transcription && (
        <div className="bg-[#E8F5E9] p-4 rounded-xl border-2 border-[#2E7D32] border-dashed">
          <div className="flex items-start gap-3">
            <span className="text-2xl">💡</span>
            <div className="flex-1">
              <p className="text-[#2E7D32] text-sm">{t.example}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
