import { useState } from 'react';
import { motion } from 'motion/react';

interface CaptureImageProps {
  onCapture: (imageUrl: string) => void;
}

export function CaptureImage({ onCapture }: CaptureImageProps) {
  const [showHint, setShowHint] = useState(true);

  const handleTakePhoto = () => {
    // Simulate camera capture - in real app, this would use device camera
    // Using a sample product image
    onCapture('https://images.unsplash.com/photo-1761210719325-283557e92487?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kbWFkZSUyMHBvdHRlcnklMjBib3dsfGVufDF8fHx8MTc2NjY2ODc3NHww&ixlib=rb-4.1.0&q=80&w=1080');
  };

  return (
    <div className="h-full flex flex-col bg-[#1A1A1A] relative">
      {/* Camera Viewfinder */}
      <div className="flex-1 relative overflow-hidden">
        {/* Grid Overlay */}
        <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 z-10 pointer-events-none">
          {[...Array(4)].map((_, i) => (
            <div key={`v-${i}`} className="border-r border-white/20" />
          ))}
          {[...Array(4)].map((_, i) => (
            <div key={`h-${i}`} className="border-b border-white/20 col-span-3" />
          ))}
        </div>

        {/* Focus Frame */}
        <div className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none">
          <div className="w-64 h-64 border-4 border-[#FF6F00] rounded-2xl">
            {/* Corner markers */}
            <div className="absolute -top-1 -left-1 w-8 h-8 border-t-4 border-l-4 border-white" />
            <div className="absolute -top-1 -right-1 w-8 h-8 border-t-4 border-r-4 border-white" />
            <div className="absolute -bottom-1 -left-1 w-8 h-8 border-b-4 border-l-4 border-white" />
            <div className="absolute -bottom-1 -right-1 w-8 h-8 border-b-4 border-r-4 border-white" />
          </div>
        </div>

        {/* Hint Banner */}
        {showHint && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute top-4 left-4 right-4 bg-[#FF6F00] rounded-xl p-4 z-30"
          >
            <div className="flex items-start gap-3">
              <span className="text-2xl">💡</span>
              <div className="flex-1">
                <p className="text-white">Good lighting helps!</p>
                <p className="text-white/80 text-sm mt-1">Place product in bright area</p>
              </div>
              <button
                onClick={() => setShowHint(false)}
                className="text-white text-xl"
              >
                ×
              </button>
            </div>
          </motion.div>
        )}

        {/* Placeholder camera view */}
        <div className="w-full h-full bg-gradient-to-b from-gray-700 to-gray-900 flex items-center justify-center">
          <span className="text-9xl opacity-20">📷</span>
        </div>
      </div>

      {/* Bottom Controls */}
      <div className="bg-[#2A2A2A] p-6 pb-28">
        <div className="flex items-center justify-center gap-8">
          {/* Gallery Button */}
          <button className="w-14 h-14 rounded-xl bg-white/10 border-2 border-white/30 flex items-center justify-center">
            <span className="text-2xl">🖼️</span>
          </button>

          {/* Capture Button */}
          <motion.button
            onClick={handleTakePhoto}
            className="w-20 h-20 rounded-full bg-white border-4 border-[#FF6F00] shadow-2xl active:scale-90 transition-transform flex items-center justify-center"
            whileTap={{ scale: 0.9 }}
          >
            <div className="w-16 h-16 rounded-full bg-[#FF6F00]" />
          </motion.button>

          {/* Flash Button */}
          <button className="w-14 h-14 rounded-xl bg-white/10 border-2 border-white/30 flex items-center justify-center">
            <span className="text-2xl">⚡</span>
          </button>
        </div>

        {/* Instructions */}
        <p className="text-white text-center mt-4 text-lg">
          Take a clear photo of your product
        </p>
      </div>
    </div>
  );
}
