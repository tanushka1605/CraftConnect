
  # CraftConnect E-commerce App Design

  This is a code bundle for CraftConnect E-commerce App Design. The original project is available at https://www.figma.com/design/9phObqO0qtJkqet7lVkdB4/CraftConnect-E-commerce-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  